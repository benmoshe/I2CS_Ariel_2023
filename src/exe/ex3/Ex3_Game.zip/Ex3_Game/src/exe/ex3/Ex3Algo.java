package exe.ex3;

import java.awt.*;

import exe.ex3.PacManAlgo;
import exe.ex3.PacManGame;
import exe.ex3.PacManGame.Dir;

/**
 * Ex3, School of Computer Science, I2CS, Ariel University.
 * This is the main algorithmic class for Ex3 - the PacMan game.
 */
public class Ex3Algo implements PacManAlgo{

    @Override
    public String getInfo() {
        return "This is the main algorithmic class you should implement,"
        		+ "do edit this string to represent your algorithm";
    }
    @Override
    public PacManGame.Dir move(PacManGame game) {
        PacManGame.Dir ans = null;
        /**
         * Add you code here - including additional methods and classes (if needed).
         */
        return ans;
    }
}
